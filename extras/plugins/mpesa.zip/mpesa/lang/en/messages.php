<?php

return [
    'Payment Details' => 'Payment Details',
    'Payment with Mpesa' => 'Payment with Mpesa',
    'instructions' => 'Instructions',
    'enter_phone_number' => 'Enter your phone number',
    "Phone Number" => "Phone Number",
    "enter_mpesa_pin" => "Enter your Mpesa PIN to complete the payment",
    
];